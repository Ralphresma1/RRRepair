﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalSystem
{
    public class StoreItems
    {
        public string Code { get; set; }
        public string Item { get; set; }
        public int Price { get; set; }
        public int Stock { get; set; }
        public int Total { get; set; }
        public string Pic { get; set; }

    }
}
