﻿namespace FinalSystem
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backBtn = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.itemBox = new System.Windows.Forms.TextBox();
            this.itemErr = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.priceBox = new System.Windows.Forms.TextBox();
            this.priceErr = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.stockDrop = new System.Windows.Forms.NumericUpDown();
            this.stockErr = new System.Windows.Forms.Label();
            this.genErr = new System.Windows.Forms.Label();
            this.updateBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.stockDrop)).BeginInit();
            this.SuspendLayout();
            // 
            // backBtn
            // 
            this.backBtn.AutoSize = true;
            this.backBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.backBtn.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backBtn.Location = new System.Drawing.Point(25, 40);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(96, 16);
            this.backBtn.TabIndex = 23;
            this.backBtn.Text = "< Back to admin";
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift Condensed", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(179, 48);
            this.label1.TabIndex = 25;
            this.label1.Text = "Update Item";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 16);
            this.label2.TabIndex = 28;
            this.label2.Text = "Item";
            // 
            // itemBox
            // 
            this.itemBox.Location = new System.Drawing.Point(28, 158);
            this.itemBox.Name = "itemBox";
            this.itemBox.Size = new System.Drawing.Size(297, 22);
            this.itemBox.TabIndex = 29;
            this.itemBox.TextChanged += new System.EventHandler(this.itemBox_TextChanged);
            this.itemBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.itemBox_KeyPress);
            // 
            // itemErr
            // 
            this.itemErr.AutoSize = true;
            this.itemErr.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemErr.ForeColor = System.Drawing.Color.Red;
            this.itemErr.Location = new System.Drawing.Point(312, 139);
            this.itemErr.Name = "itemErr";
            this.itemErr.Size = new System.Drawing.Size(13, 16);
            this.itemErr.TabIndex = 30;
            this.itemErr.Text = "*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 195);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 16);
            this.label3.TabIndex = 31;
            this.label3.Text = "Price";
            // 
            // priceBox
            // 
            this.priceBox.Location = new System.Drawing.Point(28, 214);
            this.priceBox.Name = "priceBox";
            this.priceBox.Size = new System.Drawing.Size(120, 22);
            this.priceBox.TabIndex = 32;
            this.priceBox.TextChanged += new System.EventHandler(this.priceBox_TextChanged);
            this.priceBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.priceBox_KeyPress);
            // 
            // priceErr
            // 
            this.priceErr.AutoSize = true;
            this.priceErr.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.priceErr.ForeColor = System.Drawing.Color.Red;
            this.priceErr.Location = new System.Drawing.Point(135, 195);
            this.priceErr.Name = "priceErr";
            this.priceErr.Size = new System.Drawing.Size(13, 16);
            this.priceErr.TabIndex = 33;
            this.priceErr.Text = "*";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(206, 195);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 16);
            this.label4.TabIndex = 34;
            this.label4.Text = "Stock";
            // 
            // stockDrop
            // 
            this.stockDrop.Location = new System.Drawing.Point(209, 214);
            this.stockDrop.Name = "stockDrop";
            this.stockDrop.Size = new System.Drawing.Size(116, 22);
            this.stockDrop.TabIndex = 35;
            this.stockDrop.ValueChanged += new System.EventHandler(this.stockDrop_ValueChanged);
            // 
            // stockErr
            // 
            this.stockErr.AutoSize = true;
            this.stockErr.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stockErr.ForeColor = System.Drawing.Color.Red;
            this.stockErr.Location = new System.Drawing.Point(312, 195);
            this.stockErr.Name = "stockErr";
            this.stockErr.Size = new System.Drawing.Size(13, 16);
            this.stockErr.TabIndex = 36;
            this.stockErr.Text = "*";
            // 
            // genErr
            // 
            this.genErr.AutoSize = true;
            this.genErr.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genErr.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.genErr.Location = new System.Drawing.Point(26, 255);
            this.genErr.Name = "genErr";
            this.genErr.Size = new System.Drawing.Size(148, 12);
            this.genErr.TabIndex = 38;
            this.genErr.Text = "Boxes marked with * is required";
            // 
            // updateBtn
            // 
            this.updateBtn.BackColor = System.Drawing.Color.Green;
            this.updateBtn.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.updateBtn.Location = new System.Drawing.Point(28, 291);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(297, 48);
            this.updateBtn.TabIndex = 39;
            this.updateBtn.Text = "Update Item";
            this.updateBtn.UseVisualStyleBackColor = false;
            this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(379, 450);
            this.Controls.Add(this.updateBtn);
            this.Controls.Add(this.genErr);
            this.Controls.Add(this.stockErr);
            this.Controls.Add(this.stockDrop);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.priceErr);
            this.Controls.Add(this.priceBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.itemErr);
            this.Controls.Add(this.itemBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.backBtn);
            this.Name = "Form7";
            this.Text = "Form7";
            this.Load += new System.EventHandler(this.Form7_Load);
            ((System.ComponentModel.ISupportInitialize)(this.stockDrop)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label backBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox itemBox;
        private System.Windows.Forms.Label itemErr;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox priceBox;
        private System.Windows.Forms.Label priceErr;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown stockDrop;
        private System.Windows.Forms.Label stockErr;
        private System.Windows.Forms.Label genErr;
        private System.Windows.Forms.Button updateBtn;
    }
}