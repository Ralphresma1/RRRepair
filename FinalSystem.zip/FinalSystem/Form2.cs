﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace FinalSystem
{
    public partial class Form2 : Form
    {
        string refID = "";
        int labor = 100;
        public Form2()
        {
            InitializeComponent();
        }

        private void nameBox_TextChanged(object sender, EventArgs e)
        {
            if (nameBox.Text == string.Empty)
            {
                nameErr.Visible = true;
            }
            else
            {
                nameErr.Visible = false;
            }
        }

        private void itemBox_TextChanged(object sender, EventArgs e)
        {
            if (itemBox.Text == string.Empty)
            {
                itemErr.Visible = true;
            }
            else
            {
                itemErr.Visible = false;
            }
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            if(numericUpDown1.Value == 0)
            {
                quantityErr.Visible = true;
            }
            else
            {
                quantityErr.Visible = false;
                laborFee.Text = "₱" + Convert.ToString(labor * numericUpDown1.Value) + ".00";
            }
        }

        private void reasonBox_TextChanged(object sender, EventArgs e)
        {
            if(reasonBox.Text == string.Empty)
            {
                reasonErr.Visible = true;
            }
            else
            {
                reasonErr.Visible = false;
            }
        }

        private void submitBtn_Click(object sender, EventArgs e)
        {
            string guid = Guid.NewGuid().ToString();

            string timestamp = DateTime.Now.ToString("yyyyMMddHHmmss");

            refID = $"{guid}-{timestamp}";

            if (nameErr.Visible == false && itemErr.Visible == false && quantityErr.Visible == false && reasonErr.Visible == false)
            {
                try
                {
                    string sql = "INSERT INTO repair(ReferenceID,Client,Item,Quantity,Fee,Reason)" + "values('" + refID + "'," + 
                    " '" + nameBox.Text + "'," +
                    " '" + itemBox.Text + "'," +
                    " " + numericUpDown1.Value + "," +
                    " " + labor * numericUpDown1.Value + "," +
                    " '" + reasonBox.Text + "')";
                    DBhelper.DBhelper.ModifyRecord(sql);
                    MessageBox.Show("Request for repair has been submitted...", "Request for repair", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    clearFields();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please make sure to input all required fields. Try again.");
            }
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Close();
        }

        private void storeBtn_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void clearFields()
        {
            nameBox.Text = string.Empty;
            itemBox.Text = string.Empty;
            numericUpDown1.Value = 0;
            reasonBox.Text = string.Empty;
        }

        private void nameBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && char.IsSymbol(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void itemBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && char.IsSymbol(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
