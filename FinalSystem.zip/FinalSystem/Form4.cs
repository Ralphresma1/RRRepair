﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalSystem
{
    public partial class Form4 : Form
    {
        int total = 0, change = 0, cash = 0;
        public Form4()
        {
            InitializeComponent();

        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void removeBtn_Click(object sender, EventArgs e)
        {
            if(viewCart.SelectedRows.Count > 0)
            {
                DataGridViewRow cell = viewCart.SelectedRows[0];

                string cellVal = cell.Cells["Code"].Value.ToString();
                string stockVal = cell.Cells["Quantity"].Value.ToString();

                if(cellVal == null)
                {
                    MessageBox.Show("You have not selected an item to remove.");
                } 
                else
                {
                    string sql = "DELETE * FROM cart WHERE Code = '" + cellVal + "'";
                    DBhelper.DBhelper.ModifyRecord(sql);

                    string sql1 = "UPDATE store SET Stock = Stock + " + Convert.ToInt32(stockVal) + " WHERE Code = '" + cellVal + "'";
                    DBhelper.DBhelper.ModifyRecord(sql1);

                    string sql2 = "SELECT * FROM cart";
                    DBhelper.DBhelper.fill(sql2, viewCart);
                    viewCart.Refresh();

                    Connection.Connection.DB();
                    string query = "SELECT * FROM cart";

                    GlobalDeclaration.command = new OleDbCommand(query, Connection.Connection.conn);

                    GlobalDeclaration.reader = GlobalDeclaration.command.ExecuteReader();

                    List<StoreItems> storeList = new List<StoreItems>();

                    while (GlobalDeclaration.reader.Read())
                    {
                        storeList.Add(new StoreItems { Code = GlobalDeclaration.reader["Code"].ToString(), Item = GlobalDeclaration.reader["Item"].ToString(), Price = Convert.ToInt32(GlobalDeclaration.reader["Price"].ToString()), Total = Convert.ToInt32(GlobalDeclaration.reader["Total"].ToString()) });
                    }

                    total = 0;

                    foreach (StoreItems item in storeList)
                    {
                        total += Convert.ToInt32(item.Total);
                    }

                    allTotal.Text = "₱" + total.ToString() + ".00";
                }
            }
            else
            {
                MessageBox.Show("Please select an item to remove.");
            }
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            payErr.Visible = false;

            string sql = "SELECT * FROM cart";
            DBhelper.DBhelper.fill(sql, viewCart);

            Connection.Connection.DB();
            string query = "SELECT * FROM cart";

            GlobalDeclaration.command = new OleDbCommand(query, Connection.Connection.conn);

            GlobalDeclaration.reader = GlobalDeclaration.command.ExecuteReader();

            List<StoreItems> storeList = new List<StoreItems>();

            while (GlobalDeclaration.reader.Read())
            {
                storeList.Add(new StoreItems { Code = GlobalDeclaration.reader["Code"].ToString(), Item = GlobalDeclaration.reader["Item"].ToString(), Price = Convert.ToInt32(GlobalDeclaration.reader["Price"].ToString()), Total = Convert.ToInt32(GlobalDeclaration.reader["Total"].ToString()) });
            }

            foreach (StoreItems item in storeList)
            {
                total += Convert.ToInt32(item.Total);
            }

            allTotal.Text = "₱" + total.ToString() + ".00";
        }

        private void checkOut_Click(object sender, EventArgs e)
        {
            if(cash > total)
            {
                var result = MessageBox.Show("Are you sure you want to checkout?", "Checkout", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    string sql = "DELETE FROM cart";
                    DBhelper.DBhelper.ModifyRecord(sql);
                    MessageBox.Show("You have checked out succesfully!");
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("You have not paid yet. Please try again");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if(textBox1.Text.Length > 0)
            {
                cash = Convert.ToInt32(textBox1.Text);
            } else
            {
                changeTotal.Text = "0.00";
            }

            if(cash < total)
            {
                payErr.Visible = true;
            }
            else
            {
                payErr.Visible = false;
                change = cash - total;
                changeTotal.Text = "₱" + change.ToString() + ".00";
            }
        }
    }
}
