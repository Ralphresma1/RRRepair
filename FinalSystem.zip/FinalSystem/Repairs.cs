﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalSystem
{
    internal class Repairs
    {
        public string Client { get; set; }
        public string Item { get; set; }
        public int Quantity { get; set; }
        public int Fee { get; set; }
        public string Reason { get; set; }
        public string ReferenceID { get; set; }
    }
}
