﻿using FinalSystem.DBhelper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace FinalSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            genErr.Visible = false;
            passErr.Visible = false;
            userErr.Visible = false;
        }

        private void userBox_TextChanged(object sender, EventArgs e)
        {
            //Check user input for symbols
            Regex check = new Regex("^[a-zA-Z0-9]*$");

            if(check.IsMatch(userBox.Text))
            {
                userErr.Visible = false;
            }
            else
            {
                userErr.Visible = true;
            }
        }

        private void passBox_TextChanged(object sender, EventArgs e)
        {
            //Check user input for symbols
            Regex check = new Regex("^[a-zA-Z0-9]*$");

            if (check.IsMatch(userBox.Text))
            {
                userErr.Visible = false;
            }
            else
            {
                userErr.Visible = true;
            }
        }

        private void showPass_CheckedChanged(object sender, EventArgs e)
        {
            if (showPass.Checked)
            {
                passBox.UseSystemPasswordChar = false;
            }
            else
            {
                passBox.UseSystemPasswordChar = true;
            }
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            try
            {
                Connection.Connection.DB();
                string query = "SELECT COUNT(*) FROM users WHERE user=? AND pass=?";
                DBhelper.DBhelper.command = new OleDbCommand(query, Connection.Connection.conn);
                DBhelper.DBhelper.command.Parameters.AddWithValue("@user", userBox.Text);
                DBhelper.DBhelper.command.Parameters.AddWithValue("@pass", passBox.Text);

                int result = (int)DBhelper.DBhelper.command.ExecuteScalar();
                if (result > 0)
                {
                    timer1.Enabled = true;
                    timer1.Start();
                    timer1_Tick(sender, e);
                    loading.BackColor = Color.Red;
                    loading.ForeColor = Color.Red;

                    Connection.Connection.conn.Close();
                }
                else
                {
                    genErr.Visible = true;
                }
            }

            catch (Exception ex)
            {
                Connection.Connection.conn.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            loading.Increment(4);
            loading.BackColor = Color.Red;
            loading.ForeColor = Color.Red;
           
            if (loading.Value == 100)
            {
                Form2 form2 = new Form2();
                form2.Show();
                this.Hide();
                timer1.Stop();
            }
        }

        private void loginAdmin_Click(object sender, EventArgs e)
        {
            try
            {
                Connection.Connection.DB();
                string query = "SELECT COUNT(*) FROM admins WHERE user=? AND pass=?";
                DBhelper.DBhelper.command = new OleDbCommand(query, Connection.Connection.conn);
                DBhelper.DBhelper.command.Parameters.AddWithValue("@user", userBox.Text);
                DBhelper.DBhelper.command.Parameters.AddWithValue("@pass", passBox.Text);

                int result = (int)DBhelper.DBhelper.command.ExecuteScalar();
                if (result > 0)
                {
                    
                    timer2.Enabled = true;
                    timer2.Start();
                    timer2_Tick(sender, e);
                    Connection.Connection.conn.Close();
                }
                else
                {
                    genErr.Visible = true;
                }
            }

            catch (Exception ex)
            {
                Connection.Connection.conn.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            loading.Increment(4);
            loading.BackColor = Color.Blue;
            loading.ForeColor = Color.Blue;
            loading.BackColor = Color.Blue;

            if (loading.Value == 100)
            {
                Form5 form5 = new Form5();
                form5.Show();
                this.Hide();
                timer2.Stop();
            }
        }

        private void loading_Click(object sender, EventArgs e)
        {
            
        }
    }
}
