﻿using FinalSystem.DBhelper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalSystem
{
    public partial class Form3 : Form
    {
        string code = "", itemprice = "";
        //int total = 0;
        public Form3()
        {
            InitializeComponent();

            Connection.Connection.DB();
            string query = "SELECT * FROM store";

            GlobalDeclaration.command = new OleDbCommand(query, Connection.Connection.conn);

            GlobalDeclaration.reader = GlobalDeclaration.command.ExecuteReader();

            List<StoreItems> storeList = new List<StoreItems>();

            while (GlobalDeclaration.reader.Read())
            {
                storeList.Add(new StoreItems { Code = GlobalDeclaration.reader["Code"].ToString(), Item = GlobalDeclaration.reader["Item"].ToString(), Price = Convert.ToInt32(GlobalDeclaration.reader["Price"].ToString()), Stock = Convert.ToInt32(GlobalDeclaration.reader["Stock"].ToString()) }) ;
            }

            foreach (StoreItems item in storeList)
            {
                storeItems.Items.Add(item.Item);
            }
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            itemErr.Visible = false;
            quanErr.Visible = false;
            buyErr.Visible = false;
            itemPic.Image = null;
        }

        private void storeItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            getStoreData();
        }

        private void viewCart_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
        }

        private void quantity_ValueChanged(object sender, EventArgs e)
        {
            if(quantity.Value > Convert.ToInt32(stockCount.Text))
            {
                quanErr.Visible = true;
                MessageBox.Show("The quantity inputted is exceeding the available stock, please try again.");
            }
            else
            {
                quanErr.Visible = false;
            }
        }

        private void addToCart_Click(object sender, EventArgs e)
        {
            int stock = Convert.ToInt32(stockCount.Text);
            int quant = Convert.ToInt32(quantity.Value);
            int newStock = stock - quant;
            int total = Convert.ToInt32(itemprice) * quant;

            try
            {
                if (storeItems.SelectedItem == null)
                {
                    buyErr.Visible = true;
                    itemErr.Visible = true;
                    quanErr.Visible = false;
                }
                else if(quantity.Value == 0)
                {
                    quanErr.Visible = true;
                    buyErr.Visible = true;
                    itemErr.Visible = false;
                }
                else if (quant > 0 && storeItems.SelectedItem != null && quanErr.Visible == false)
                {
                    string sql = "INSERT INTO cart(Code,Item,Price,Quantity,Total)" + "values('" + code + "'," +
                    " '" + storeItems.SelectedItem.ToString() + "'," +
                    " " + Convert.ToInt32(itemprice) + "," +
                    " " + quant + "," + 
                    " " + total + ")";
                    DBhelper.DBhelper.ModifyRecord(sql);
                    MessageBox.Show("Item successfully added to cart", "Add to cart", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    string sql3 = "UPDATE store SET Stock = " + newStock + " WHERE Code = '" + code + "'";
                    DBhelper.DBhelper.ModifyRecord(sql3);

                    buyErr.Visible = false;
                    quanErr.Visible = false;
                    itemErr.Visible = false;

                    getStoreData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void itemPic_Click(object sender, EventArgs e)
        {

        }

        private void getStoreData()
        {
            Connection.Connection.DB();
            string query = "SELECT * FROM store";

            GlobalDeclaration.command = new OleDbCommand(query, Connection.Connection.conn);

            GlobalDeclaration.reader = GlobalDeclaration.command.ExecuteReader();

            List<StoreItems> storeList = new List<StoreItems>();

            while (GlobalDeclaration.reader.Read())
            {
                storeList.Add(new StoreItems { Code = GlobalDeclaration.reader["Code"].ToString(), Item = GlobalDeclaration.reader["Item"].ToString(), Price = Convert.ToInt32(GlobalDeclaration.reader["Price"].ToString()), Stock = Convert.ToInt32(GlobalDeclaration.reader["Stock"].ToString()), Pic = GlobalDeclaration.reader["Pic"].ToString() });
            }

            int selectedItem = storeItems.SelectedIndex;

            price.Text = "₱" + storeList[selectedItem].Price.ToString() + ".00";
            stockCount.Text = storeList[selectedItem].Stock.ToString();
            code = storeList[selectedItem].Code.ToString();
            itemprice = storeList[selectedItem].Price.ToString();
            itemPic.Image = Image.FromFile(@"C:\Users\Ralph\OneDrive\Desktop\Final Project - System\FinalSystem\Resources\" + storeList[selectedItem].Pic.ToString() + "");
        }
    }
}
