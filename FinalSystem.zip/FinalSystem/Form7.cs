﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalSystem
{
    public partial class Form7 : Form
    {
        string codetxt = "";
        public Form7(string code)
        {
            InitializeComponent();

            codetxt = code;

            label1.Text = "Update " + codetxt + "";

            itemErr.Visible = false;
            priceErr.Visible = false;
            stockErr.Visible = false;
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void itemBox_TextChanged(object sender, EventArgs e)
        {
            if (itemBox.Text == "")
            {
                itemErr.Visible = true;
            }
            else
            {
                itemErr.Visible = false;
            }
        }

        private void priceBox_TextChanged(object sender, EventArgs e)
        {
            if (priceBox.Text == "")
            {
                priceErr.Visible = true;
            }
            else
            {
                priceErr.Visible = false;
            }
        }

        private void stockDrop_ValueChanged(object sender, EventArgs e)
        {
            if (stockDrop.Value == 0)
            {
                stockErr.Visible = true;
            }
            else
            {
                stockErr.Visible = false;
            }
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            if (priceErr.Visible == false && stockErr.Visible == false &&  itemErr.Visible == false)
            {
                var result = MessageBox.Show("Are you sure you want to update this item?", "Update item", MessageBoxButtons.YesNo);

                if (result == DialogResult.Yes)
                {
                    string sql = "UPDATE store SET Item = '" + itemBox.Text + "',Price = " + Convert.ToInt32(priceBox.Text) + ",Stock = " + stockDrop.Value + " WHERE Code = '" + codetxt + "'";
                    DBhelper.DBhelper.ModifyRecord(sql);
                    this.Close();
                }
            } 
            else
            {
                MessageBox.Show("Please make sure to input all required fields. Try again.");
            }
        }

        private void itemBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && char.IsSymbol(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void priceBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            Connection.Connection.DB();
            //string sql = "SELECT Item, Price, Stock FROM store WHERE Code = @Code";
            string sql = "SELECT * FROM store";

            GlobalDeclaration.command = new OleDbCommand(sql, Connection.Connection.conn);

            GlobalDeclaration.reader = GlobalDeclaration.command.ExecuteReader();

            while (GlobalDeclaration.reader.Read())
            {
                if (GlobalDeclaration.reader["Code"].ToString() == codetxt)
                {
                    itemBox.Text = GlobalDeclaration.reader["Item"].ToString();
                    priceBox.Text = GlobalDeclaration.reader["Price"].ToString();
                    stockDrop.Value = Convert.ToInt32(GlobalDeclaration.reader["Stock"].ToString());
                }
            }
        }
    }
}
