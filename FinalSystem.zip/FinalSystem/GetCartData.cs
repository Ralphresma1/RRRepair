﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalSystem
{
    internal class GetCartData
    {
        public static void getCartItems()
        {
            try
            {
                string sql = "Select MAX(Code)from cart";
                Connection.Connection.DB();
                GlobalDeclaration.command = new OleDbCommand(sql, Connection.Connection.conn);
                GlobalDeclaration.reader = GlobalDeclaration.command.ExecuteReader();

                if (GlobalDeclaration.reader.Read())
                {
                    sql = GlobalDeclaration.reader[0].ToString();

                    if (sql == "")
                    {
                        GlobalDeclaration.itemcode = 1;
                    }

                    else
                    {

                        GlobalDeclaration.itemcode = Convert.ToInt32(GlobalDeclaration.reader[0].ToString()) + 1;
                    }

                    GlobalDeclaration.reader.Close();

                }
                Connection.Connection.conn.Close();
            }

            catch (Exception ex)
            {
                Connection.Connection.conn.Close();
                MessageBox.Show("Error -----> GET MAX ID" + ex.Message);
            }
        }
    }
}
