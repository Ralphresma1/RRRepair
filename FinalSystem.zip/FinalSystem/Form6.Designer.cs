﻿namespace FinalSystem
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backBtn = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.codeBox = new System.Windows.Forms.TextBox();
            this.codeErr = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.itemBox = new System.Windows.Forms.TextBox();
            this.itemErr = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.priceBox = new System.Windows.Forms.TextBox();
            this.priceErr = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.stockDrop = new System.Windows.Forms.NumericUpDown();
            this.stockErr = new System.Windows.Forms.Label();
            this.addBtn = new System.Windows.Forms.Button();
            this.genErr = new System.Windows.Forms.Label();
            this.uploadBtn = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.stockDrop)).BeginInit();
            this.SuspendLayout();
            // 
            // backBtn
            // 
            this.backBtn.AutoSize = true;
            this.backBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.backBtn.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backBtn.Location = new System.Drawing.Point(32, 37);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(96, 16);
            this.backBtn.TabIndex = 22;
            this.backBtn.Text = "< Back to admin";
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(32, 127);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(36, 16);
            this.lbl1.TabIndex = 23;
            this.lbl1.Text = "Code";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift Condensed", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(223, 48);
            this.label1.TabIndex = 24;
            this.label1.Text = "Inventory Form";
            // 
            // codeBox
            // 
            this.codeBox.Location = new System.Drawing.Point(35, 146);
            this.codeBox.Name = "codeBox";
            this.codeBox.Size = new System.Drawing.Size(297, 22);
            this.codeBox.TabIndex = 25;
            this.codeBox.TextChanged += new System.EventHandler(this.codeBox_TextChanged);
            this.codeBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.codeBox_KeyPress);
            // 
            // codeErr
            // 
            this.codeErr.AutoSize = true;
            this.codeErr.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.codeErr.ForeColor = System.Drawing.Color.Red;
            this.codeErr.Location = new System.Drawing.Point(198, 127);
            this.codeErr.Name = "codeErr";
            this.codeErr.Size = new System.Drawing.Size(134, 16);
            this.codeErr.TabIndex = 26;
            this.codeErr.Text = "code is already used *";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(32, 181);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 16);
            this.label2.TabIndex = 27;
            this.label2.Text = "Item";
            // 
            // itemBox
            // 
            this.itemBox.Location = new System.Drawing.Point(35, 200);
            this.itemBox.Name = "itemBox";
            this.itemBox.Size = new System.Drawing.Size(297, 22);
            this.itemBox.TabIndex = 28;
            this.itemBox.TextChanged += new System.EventHandler(this.itemBox_TextChanged);
            this.itemBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.itemBox_KeyPress);
            // 
            // itemErr
            // 
            this.itemErr.AutoSize = true;
            this.itemErr.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemErr.ForeColor = System.Drawing.Color.Red;
            this.itemErr.Location = new System.Drawing.Point(319, 181);
            this.itemErr.Name = "itemErr";
            this.itemErr.Size = new System.Drawing.Size(13, 16);
            this.itemErr.TabIndex = 29;
            this.itemErr.Text = "*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(32, 237);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 16);
            this.label3.TabIndex = 30;
            this.label3.Text = "Price";
            // 
            // priceBox
            // 
            this.priceBox.Location = new System.Drawing.Point(35, 256);
            this.priceBox.Name = "priceBox";
            this.priceBox.Size = new System.Drawing.Size(120, 22);
            this.priceBox.TabIndex = 31;
            this.priceBox.TextChanged += new System.EventHandler(this.priceBox_TextChanged);
            this.priceBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.priceBox_KeyPress);
            // 
            // priceErr
            // 
            this.priceErr.AutoSize = true;
            this.priceErr.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.priceErr.ForeColor = System.Drawing.Color.Red;
            this.priceErr.Location = new System.Drawing.Point(142, 237);
            this.priceErr.Name = "priceErr";
            this.priceErr.Size = new System.Drawing.Size(13, 16);
            this.priceErr.TabIndex = 32;
            this.priceErr.Text = "*";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(213, 237);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 16);
            this.label4.TabIndex = 33;
            this.label4.Text = "Stock";
            // 
            // stockDrop
            // 
            this.stockDrop.Location = new System.Drawing.Point(216, 255);
            this.stockDrop.Name = "stockDrop";
            this.stockDrop.Size = new System.Drawing.Size(116, 22);
            this.stockDrop.TabIndex = 34;
            this.stockDrop.ValueChanged += new System.EventHandler(this.stockDrop_ValueChanged);
            // 
            // stockErr
            // 
            this.stockErr.AutoSize = true;
            this.stockErr.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stockErr.ForeColor = System.Drawing.Color.Red;
            this.stockErr.Location = new System.Drawing.Point(319, 236);
            this.stockErr.Name = "stockErr";
            this.stockErr.Size = new System.Drawing.Size(13, 16);
            this.stockErr.TabIndex = 35;
            this.stockErr.Text = "*";
            // 
            // addBtn
            // 
            this.addBtn.BackColor = System.Drawing.Color.Green;
            this.addBtn.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.addBtn.Location = new System.Drawing.Point(35, 386);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(297, 48);
            this.addBtn.TabIndex = 36;
            this.addBtn.Text = "Add Item";
            this.addBtn.UseVisualStyleBackColor = false;
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // genErr
            // 
            this.genErr.AutoSize = true;
            this.genErr.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genErr.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.genErr.Location = new System.Drawing.Point(33, 346);
            this.genErr.Name = "genErr";
            this.genErr.Size = new System.Drawing.Size(148, 12);
            this.genErr.TabIndex = 37;
            this.genErr.Text = "Boxes marked with * is required";
            // 
            // uploadBtn
            // 
            this.uploadBtn.Location = new System.Drawing.Point(35, 302);
            this.uploadBtn.Name = "uploadBtn";
            this.uploadBtn.Size = new System.Drawing.Size(120, 23);
            this.uploadBtn.TabIndex = 38;
            this.uploadBtn.Text = "upload image";
            this.uploadBtn.UseVisualStyleBackColor = true;
            this.uploadBtn.Click += new System.EventHandler(this.uploadBtn_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(378, 470);
            this.Controls.Add(this.uploadBtn);
            this.Controls.Add(this.genErr);
            this.Controls.Add(this.addBtn);
            this.Controls.Add(this.stockErr);
            this.Controls.Add(this.stockDrop);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.priceErr);
            this.Controls.Add(this.priceBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.itemErr);
            this.Controls.Add(this.itemBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.codeErr);
            this.Controls.Add(this.codeBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.backBtn);
            this.Name = "Form6";
            this.Text = "Form6";
            this.Load += new System.EventHandler(this.Form6_Load);
            ((System.ComponentModel.ISupportInitialize)(this.stockDrop)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label backBtn;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox codeBox;
        private System.Windows.Forms.Label codeErr;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox itemBox;
        private System.Windows.Forms.Label itemErr;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox priceBox;
        private System.Windows.Forms.Label priceErr;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown stockDrop;
        private System.Windows.Forms.Label stockErr;
        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.Label genErr;
        private System.Windows.Forms.Button uploadBtn;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}