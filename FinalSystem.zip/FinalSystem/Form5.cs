﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalSystem
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();

            dataView.Refresh();
        }

        private void storeInventory_CheckedChanged(object sender, EventArgs e)
        {
            if( storeInventory.Checked )
            {
                finishBtn.Enabled = false;
                addBtn.Enabled = true;
                deleteBtn.Enabled = true;
                updateBtn.Enabled = true;

                string sql = "SELECT * FROM store";
                DBhelper.DBhelper.fill(sql, dataView);
            }
        }

        private void forRepair_CheckedChanged(object sender, EventArgs e)
        {
            if( forRepair.Checked ) 
            { 
                addBtn.Enabled = false;
                deleteBtn.Enabled = false; 
                updateBtn.Enabled = false;
                finishBtn.Enabled = true;

                string sql = "SELECT * FROM repair";
                DBhelper.DBhelper.fill(sql, dataView);
            }
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            storeInventory.Checked = false;
            Form6 form6 = new Form6();
            form6.Show();
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (dataView.SelectedRows.Count > 0)
            {
                DataGridViewRow cell = dataView.SelectedRows[0];

                string cellVal = cell.Cells["Code"].Value.ToString();

                if (cellVal == null)
                {
                    MessageBox.Show("You have not selected an item to remove.");
                }
                else
                {
                    var result = MessageBox.Show("Are you sure you want to remove this item from the inventory?", "Remove item", MessageBoxButtons.YesNo);
                    
                    if( result == DialogResult.Yes )
                    {
                        string sql = "DELETE * FROM store WHERE Code = '" + cellVal + "'";
                        DBhelper.DBhelper.ModifyRecord(sql);

                        string sql2 = "SELECT * FROM store";
                        DBhelper.DBhelper.fill(sql2, dataView);
                        dataView.Refresh();
                    }
                }
            }
            else
            {
                MessageBox.Show("You have not selected an item to remove.");
            }
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            if (dataView.SelectedRows.Count > 0)
            {
                DataGridViewRow cell = dataView.SelectedRows[0];

                string cellVal = cell.Cells["Code"].Value.ToString();

                if (cellVal == null)
                {
                    MessageBox.Show("You have not selected an item to update.");
                }
                else
                {
                    storeInventory.Checked = false;
                    Form7 form7 = new Form7(cellVal);
                    form7.Show();
                }
            }
            else
            {
                MessageBox.Show("You have not selected an item to update.");
            }
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void finishBtn_Click(object sender, EventArgs e)
        {
            if (dataView.SelectedRows.Count > 0)
            {
                DataGridViewRow cell = dataView.SelectedRows[0];

                string cellVal = cell.Cells["ReferenceID"].Value.ToString();

                if (cellVal == null)
                {
                    MessageBox.Show("You have not selected an item to remove.");
                }
                else
                {
                    var result = MessageBox.Show("Are you sure this item is finished repairing?", "Item repaired", MessageBoxButtons.YesNo);

                    if (result == DialogResult.Yes)
                    {
                        string sql = "DELETE * FROM repair WHERE ReferenceID = '" + cellVal + "'";
                        DBhelper.DBhelper.ModifyRecord(sql);

                        string sql2 = "SELECT * FROM repair";
                        DBhelper.DBhelper.fill(sql2, dataView);
                        dataView.Refresh();
                    }
                }
            }
            else
            {
                MessageBox.Show("You have not selected an item to finish repair.");
            }
        }

        private void dataView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
