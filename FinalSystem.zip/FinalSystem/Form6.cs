﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalSystem
{
    public partial class Form6 : Form
    {
        string pic = "";
        public Form6()
        {
            InitializeComponent();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void codeBox_TextChanged(object sender, EventArgs e)
        {
            Connection.Connection.DB();
            string sql = "SELECT COUNT(*) FROM store WHERE Code = '" + codeBox.Text + "'";
            DBhelper.DBhelper.command = new OleDbCommand(sql, Connection.Connection.conn);
            DBhelper.DBhelper.command.Parameters.AddWithValue("@Code", codeBox.Text);

            int result = (int)DBhelper.DBhelper.command.ExecuteScalar();
            if (result > 0)
            {
                codeErr.Visible = true;
            }
            else
            {
                codeErr.Visible = false;
            }

            Connection.Connection.conn.Close();
        }

        private void itemBox_TextChanged(object sender, EventArgs e)
        {
            if(itemBox.Text == "")
            {
                itemErr.Visible = true;
            }
            else
            {
                itemErr.Visible = false;
            }
        }

        private void priceBox_TextChanged(object sender, EventArgs e)
        {
            if (priceBox.Text == "")
            {
                priceErr.Visible = true;
            }
            else
            {
                priceErr.Visible = false;
            }
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            if(priceErr.Visible == false &&  stockErr.Visible == false && codeErr.Visible == false && itemErr.Visible == false && pic != "")
            {
                string sql = "INSERT INTO store(Code,Item,Price,Stock,Pic)" + "values('" + codeBox.Text + "'," +
                    " '" + itemBox.Text + "'," +
                    " " + Convert.ToInt32(priceBox.Text) + "," +
                    " " + Convert.ToInt32(stockDrop.Value) + 
                    " '" + pic + "'," + ")";
                DBhelper.DBhelper.ModifyRecord(sql);
                MessageBox.Show("Data has been added...", "Save new stock", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else
            {
                MessageBox.Show("Please make sure to input all required fields. Try again.");
            }
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            codeErr.Visible = false;
            itemErr.Visible = false;
            priceErr.Visible = false;
            stockErr.Visible = false;
        }

        private void codeBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && char.IsSymbol(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void itemBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && char.IsSymbol(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void priceBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void stockDrop_ValueChanged(object sender, EventArgs e)
        {
            if (stockDrop.Value == 0)
            {
                stockErr.Visible = true;
            }
            else
            {
                stockErr.Visible = false;
            }
        }

        private void uploadBtn_Click(object sender, EventArgs e)
        {
            OpenFileDialog upload = new OpenFileDialog();

            upload.Filter = "Image Files(*.jpg; *.jpeg; *.png; *.bmp)|*.jpg; *.jpeg; *.png; *.bmp|All Files (*.*)|*.*";
            upload.FilterIndex = 1;
            upload.Multiselect = false;

            DialogResult result = upload.ShowDialog();

            if (result == DialogResult.OK)
            {
                pic = upload.SafeFileName;
            }
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            /*string filePath = openFileDialog1.FileName;

            Image image = Image.FromFile(filePath);

            Properties.Resources.ResourceManager.GetObject(pic) = image;*/
        }
    }
}
