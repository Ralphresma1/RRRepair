﻿namespace FinalSystem
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.storeItems = new System.Windows.Forms.ComboBox();
            this.itemDrop = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.quantity = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.price = new System.Windows.Forms.Label();
            this.addToCart = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.stockCount = new System.Windows.Forms.Label();
            this.viewCart = new System.Windows.Forms.Button();
            this.backBtn = new System.Windows.Forms.Label();
            this.itemErr = new System.Windows.Forms.Label();
            this.quanErr = new System.Windows.Forms.Label();
            this.buyErr = new System.Windows.Forms.Label();
            this.itemPic = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.quantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemPic)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift Condensed", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(613, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 48);
            this.label1.TabIndex = 2;
            this.label1.Text = "Store";
            // 
            // storeItems
            // 
            this.storeItems.FormattingEnabled = true;
            this.storeItems.Location = new System.Drawing.Point(83, 154);
            this.storeItems.Name = "storeItems";
            this.storeItems.Size = new System.Drawing.Size(256, 24);
            this.storeItems.TabIndex = 3;
            this.storeItems.SelectedIndexChanged += new System.EventHandler(this.storeItems_SelectedIndexChanged);
            // 
            // itemDrop
            // 
            this.itemDrop.AutoSize = true;
            this.itemDrop.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemDrop.Location = new System.Drawing.Point(80, 135);
            this.itemDrop.Name = "itemDrop";
            this.itemDrop.Size = new System.Drawing.Size(71, 16);
            this.itemDrop.TabIndex = 4;
            this.itemDrop.Text = "Select item";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(80, 197);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "Quantity";
            // 
            // quantity
            // 
            this.quantity.Location = new System.Drawing.Point(83, 217);
            this.quantity.Name = "quantity";
            this.quantity.Size = new System.Drawing.Size(69, 22);
            this.quantity.TabIndex = 6;
            this.quantity.ValueChanged += new System.EventHandler(this.quantity_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(284, 197);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Price";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // price
            // 
            this.price.AutoSize = true;
            this.price.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.price.Location = new System.Drawing.Point(283, 217);
            this.price.Name = "price";
            this.price.Size = new System.Drawing.Size(46, 24);
            this.price.TabIndex = 10;
            this.price.Text = "0.00";
            this.price.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // addToCart
            // 
            this.addToCart.BackColor = System.Drawing.Color.Green;
            this.addToCart.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addToCart.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.addToCart.Location = new System.Drawing.Point(83, 267);
            this.addToCart.Name = "addToCart";
            this.addToCart.Size = new System.Drawing.Size(125, 48);
            this.addToCart.TabIndex = 13;
            this.addToCart.Text = "Add to cart";
            this.addToCart.UseVisualStyleBackColor = false;
            this.addToCart.Click += new System.EventHandler(this.addToCart_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(284, 267);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 16);
            this.label4.TabIndex = 14;
            this.label4.Text = "In stock:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // stockCount
            // 
            this.stockCount.AutoSize = true;
            this.stockCount.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stockCount.Location = new System.Drawing.Point(283, 283);
            this.stockCount.Name = "stockCount";
            this.stockCount.Size = new System.Drawing.Size(21, 24);
            this.stockCount.TabIndex = 15;
            this.stockCount.Text = "0";
            this.stockCount.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // viewCart
            // 
            this.viewCart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.viewCart.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewCart.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.viewCart.Location = new System.Drawing.Point(490, 429);
            this.viewCart.Name = "viewCart";
            this.viewCart.Size = new System.Drawing.Size(164, 48);
            this.viewCart.TabIndex = 18;
            this.viewCart.Text = "View Cart";
            this.viewCart.UseVisualStyleBackColor = false;
            this.viewCart.Click += new System.EventHandler(this.viewCart_Click);
            // 
            // backBtn
            // 
            this.backBtn.AutoSize = true;
            this.backBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.backBtn.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backBtn.Location = new System.Drawing.Point(80, 97);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(44, 16);
            this.backBtn.TabIndex = 22;
            this.backBtn.Text = "< Back";
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // itemErr
            // 
            this.itemErr.AutoSize = true;
            this.itemErr.ForeColor = System.Drawing.Color.Red;
            this.itemErr.Location = new System.Drawing.Point(327, 135);
            this.itemErr.Name = "itemErr";
            this.itemErr.Size = new System.Drawing.Size(12, 16);
            this.itemErr.TabIndex = 23;
            this.itemErr.Text = "*";
            // 
            // quanErr
            // 
            this.quanErr.AutoSize = true;
            this.quanErr.ForeColor = System.Drawing.Color.Red;
            this.quanErr.Location = new System.Drawing.Point(140, 197);
            this.quanErr.Name = "quanErr";
            this.quanErr.Size = new System.Drawing.Size(12, 16);
            this.quanErr.TabIndex = 24;
            this.quanErr.Text = "*";
            // 
            // buyErr
            // 
            this.buyErr.AutoSize = true;
            this.buyErr.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buyErr.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buyErr.Location = new System.Drawing.Point(81, 332);
            this.buyErr.Name = "buyErr";
            this.buyErr.Size = new System.Drawing.Size(150, 12);
            this.buyErr.TabIndex = 25;
            this.buyErr.Text = "Boxes marked with * is required.";
            // 
            // itemPic
            // 
            this.itemPic.Image = global::FinalSystem.Properties.Resources.Tires;
            this.itemPic.Location = new System.Drawing.Point(427, 135);
            this.itemPic.Name = "itemPic";
            this.itemPic.Size = new System.Drawing.Size(278, 288);
            this.itemPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.itemPic.TabIndex = 26;
            this.itemPic.TabStop = false;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(800, 522);
            this.Controls.Add(this.itemPic);
            this.Controls.Add(this.buyErr);
            this.Controls.Add(this.quanErr);
            this.Controls.Add(this.itemErr);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.viewCart);
            this.Controls.Add(this.stockCount);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.addToCart);
            this.Controls.Add(this.price);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.quantity);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.itemDrop);
            this.Controls.Add(this.storeItems);
            this.Controls.Add(this.label1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.quantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemPic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox storeItems;
        private System.Windows.Forms.Label itemDrop;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown quantity;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label price;
        private System.Windows.Forms.Button addToCart;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label stockCount;
        private System.Windows.Forms.Button viewCart;
        private System.Windows.Forms.Label backBtn;
        private System.Windows.Forms.Label itemErr;
        private System.Windows.Forms.Label quanErr;
        private System.Windows.Forms.Label buyErr;
        private System.Windows.Forms.PictureBox itemPic;
    }
}